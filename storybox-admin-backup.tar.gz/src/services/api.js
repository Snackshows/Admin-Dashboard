import apiClient from './apiConfig';

// Authentication APIs
export const authAPI = {
  login: (credentials) => apiClient.post('/auth/login', credentials),
  demoLogin: () => apiClient.post('/auth/demo-login'),
  logout: () => apiClient.post('/auth/logout'),
  getProfile: () => apiClient.get('/auth/profile'),
  updateProfile: (data) => apiClient.put('/auth/profile', data),
  changePassword: (data) => apiClient.put('/auth/change-password', data),
};

// Dashboard APIs
export const dashboardAPI = {
  getStats: (dateRange) => apiClient.get('/dashboard/stats', { params: dateRange }),
  getAnalytics: () => apiClient.get('/dashboard/analytics'),
};

// User Management APIs
export const userAPI = {
  getAllUsers: (params) => apiClient.get('/users', { params }),
  getUserById: (id) => apiClient.get(`/users/${id}`),
  blockUser: (id) => apiClient.put(`/users/${id}/block`),
  unblockUser: (id) => apiClient.put(`/users/${id}/unblock`),
  updateUser: (id, data) => apiClient.put(`/users/${id}`, data),
  deleteUser: (id) => apiClient.delete(`/users/${id}`),
};

// Film Category APIs
export const categoryAPI = {
  getAllCategories: () => apiClient.get('/film-categories'),
  getCategoryById: (id) => apiClient.get(`/film-categories/${id}`),
  createCategory: (data) => apiClient.post('/film-categories', data),
  updateCategory: (id, data) => apiClient.put(`/film-categories/${id}`, data),
  deleteCategory: (id) => apiClient.delete(`/film-categories/${id}`),
  toggleStatus: (id) => apiClient.patch(`/film-categories/${id}/toggle-status`),
};

// Film/Movie APIs
export const filmAPI = {
  getAllFilms: (params) => apiClient.get('/films', { params }),
  getFilmById: (id) => apiClient.get(`/films/${id}`),
  createFilm: (data) => apiClient.post('/films', data),
  updateFilm: (id, data) => apiClient.put(`/films/${id}`, data),
  deleteFilm: (id) => apiClient.delete(`/films/${id}`),
  toggleBanner: (id) => apiClient.patch(`/films/${id}/toggle-banner`),
  toggleTrending: (id) => apiClient.patch(`/films/${id}/toggle-trending`),
  toggleActive: (id) => apiClient.patch(`/films/${id}/toggle-active`),
};

// Episode APIs
export const episodeAPI = {
  getAllEpisodes: (filmId) => apiClient.get(`/films/${filmId}/episodes`),
  getEpisodeById: (id) => apiClient.get(`/episodes/${id}`),
  createEpisode: (data) => apiClient.post('/episodes', data),
  updateEpisode: (id, data) => apiClient.put(`/episodes/${id}`, data),
  deleteEpisode: (id) => apiClient.delete(`/episodes/${id}`),
  toggleLock: (id) => apiClient.patch(`/episodes/${id}/toggle-lock`),
};

// Content/Short Video APIs
export const contentAPI = {
  getAllContent: (params) => apiClient.get('/content', { params }),
  getContentById: (id) => apiClient.get(`/content/${id}`),
  createContent: (data) => apiClient.post('/content', data),
  updateContent: (id, data) => apiClient.put(`/content/${id}`, data),
  deleteContent: (id) => apiClient.delete(`/content/${id}`),
};

// Coin Plan APIs
export const coinPlanAPI = {
  getAllPlans: () => apiClient.get('/coin-plans'),
  getPlanById: (id) => apiClient.get(`/coin-plans/${id}`),
  createPlan: (data) => apiClient.post('/coin-plans', data),
  updatePlan: (id, data) => apiClient.put(`/coin-plans/${id}`, data),
  deletePlan: (id) => apiClient.delete(`/coin-plans/${id}`),
  toggleStatus: (id) => apiClient.patch(`/coin-plans/${id}/toggle-status`),
};

// VIP Plan APIs
export const vipPlanAPI = {
  getAllPlans: () => apiClient.get('/vip-plans'),
  getPlanById: (id) => apiClient.get(`/vip-plans/${id}`),
  createPlan: (data) => apiClient.post('/vip-plans', data),
  updatePlan: (id, data) => apiClient.put(`/vip-plans/${id}`, data),
  deletePlan: (id) => apiClient.delete(`/vip-plans/${id}`),
  toggleStatus: (id) => apiClient.patch(`/vip-plans/${id}/toggle-status`),
};

// Order History APIs
export const orderAPI = {
  getCoinOrders: (params) => apiClient.get('/orders/coins', { params }),
  getVIPOrders: (params) => apiClient.get('/orders/vip', { params }),
  getOrderDetails: (id) => apiClient.get(`/orders/${id}`),
};

// Settings APIs
export const settingsAPI = {
  getGeneralSettings: () => apiClient.get('/settings/general'),
  updateGeneralSettings: (data) => apiClient.put('/settings/general', data),
  getStorageSettings: () => apiClient.get('/settings/storage'),
  updateStorageSettings: (data) => apiClient.put('/settings/storage', data),
  getPaymentSettings: () => apiClient.get('/settings/payment'),
  updatePaymentSettings: (data) => apiClient.put('/settings/payment', data),
  getAdsSettings: () => apiClient.get('/settings/ads'),
  updateAdsSettings: (data) => apiClient.put('/settings/ads', data),
  getReportReasons: () => apiClient.get('/settings/report-reasons'),
  updateReportReasons: (data) => apiClient.put('/settings/report-reasons', data),
  getCurrencySettings: () => apiClient.get('/settings/currency'),
  updateCurrencySettings: (data) => apiClient.put('/settings/currency', data),
};

// Upload APIs
export const uploadAPI = {
  uploadImage: (file) => {
    const formData = new FormData();
    formData.append('image', file);
    return apiClient.post('/upload/image', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  uploadVideo: (file, onProgress) => {
    const formData = new FormData();
    formData.append('video', file);
    return apiClient.post('/upload/video', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (progressEvent) => {
        const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
        if (onProgress) onProgress(percentCompleted);
      },
    });
  },
};

// Language APIs
export const languageAPI = {
  getAllLanguages: () => apiClient.get('/languages'),
};

// Reward APIs
export const rewardAPI = {
  getRewards: () => apiClient.get('/rewards'),
  updateRewards: (data) => apiClient.put('/rewards', data),
};
