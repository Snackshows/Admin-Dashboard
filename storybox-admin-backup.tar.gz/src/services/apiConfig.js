import axios from 'axios';

// Base API configuration
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'https://api.storybox.com/api';
const API_TIMEOUT = parseInt(process.env.REACT_APP_API_TIMEOUT) || 30000;

// Create axios instance
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: API_TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request queue for handling concurrent requests
let requestQueue = [];
let isRefreshing = false;

// Request interceptor
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    // Add request timestamp for monitoring
    config.metadata = { startTime: new Date() };

    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor with retry logic
apiClient.interceptors.response.use(
  (response) => {
    // Calculate request duration for monitoring
    const duration = new Date() - response.config.metadata.startTime;
    
    if (process.env.NODE_ENV === 'development') {
      console.log(`API Request: ${response.config.url} took ${duration}ms`);
    }

    return response.data;
  },
  async (error) => {
    const originalRequest = error.config;

    // Handle network errors
    if (!error.response) {
      console.error('Network error:', error.message);
      return Promise.reject({
        message: 'Network error. Please check your internet connection.',
        type: 'network_error'
      });
    }

    // Handle 401 Unauthorized
    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        // Queue requests while refreshing token
        return new Promise((resolve, reject) => {
          requestQueue.push({ resolve, reject });
        })
          .then(token => {
            originalRequest.headers.Authorization = `Bearer ${token}`;
            return apiClient(originalRequest);
          })
          .catch(err => {
            return Promise.reject(err);
          });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        // Attempt to refresh token (implement your refresh logic)
        // const newToken = await refreshAuthToken();
        // localStorage.setItem('authToken', newToken);
        
        // For now, just logout
        localStorage.removeItem('authToken');
        window.location.href = '/login';
        
        isRefreshing = false;
        processQueue(null, null);
        
        return Promise.reject({
          message: 'Session expired. Please login again.',
          type: 'auth_error'
        });
      } catch (refreshError) {
        processQueue(refreshError, null);
        localStorage.removeItem('authToken');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }

    // Handle 403 Forbidden
    if (error.response?.status === 403) {
      return Promise.reject({
        message: 'You do not have permission to perform this action.',
        type: 'permission_error'
      });
    }

    // Handle 404 Not Found
    if (error.response?.status === 404) {
      return Promise.reject({
        message: 'The requested resource was not found.',
        type: 'not_found_error'
      });
    }

    // Handle 429 Too Many Requests
    if (error.response?.status === 429) {
      const retryAfter = error.response.headers['retry-after'] || 60;
      return Promise.reject({
        message: `Too many requests. Please try again in ${retryAfter} seconds.`,
        type: 'rate_limit_error',
        retryAfter
      });
    }

    // Handle 500 Server Errors
    if (error.response?.status >= 500) {
      return Promise.reject({
        message: 'Server error. Please try again later.',
        type: 'server_error'
      });
    }

    // Handle validation errors (400, 422)
    if (error.response?.status === 400 || error.response?.status === 422) {
      return Promise.reject({
        message: error.response.data?.message || 'Validation error',
        errors: error.response.data?.errors || {},
        type: 'validation_error'
      });
    }

    // Default error handling
    return Promise.reject({
      message: error.response?.data?.message || 'An unexpected error occurred',
      type: 'unknown_error',
      status: error.response?.status
    });
  }
);

// Process queued requests
function processQueue(error, token = null) {
  requestQueue.forEach(prom => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  requestQueue = [];
}

// Retry failed requests
export const retryRequest = (config, maxRetries = 3, delay = 1000) => {
  return new Promise((resolve, reject) => {
    const attempt = (retryCount) => {
      apiClient(config)
        .then(resolve)
        .catch((error) => {
          if (retryCount < maxRetries && error.type === 'network_error') {
            console.log(`Retrying request... Attempt ${retryCount + 1}/${maxRetries}`);
            setTimeout(() => attempt(retryCount + 1), delay * Math.pow(2, retryCount));
          } else {
            reject(error);
          }
        });
    };
    attempt(0);
  });
};

export default apiClient;
