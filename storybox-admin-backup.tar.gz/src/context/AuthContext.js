import React, { createContext, useContext, useState, useEffect } from 'react';
import { authAPI } from '../services/api';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = localStorage.getItem('authToken');
    if (token) {
      try {
        // DUMMY DATA MODE - Skip API call
        const dummyUser = {
          id: 1,
          name: 'Demo Admin',
          email: 'demo@admin.com',
          avatar: null,
          role: 'admin'
        };
        setUser(dummyUser);
        setIsAuthenticated(true);
        
        // UNCOMMENT WHEN CONNECTING REAL API
        // const userData = await authAPI.getProfile();
        // setUser(userData);
        // setIsAuthenticated(true);
      } catch (error) {
        localStorage.removeItem('authToken');
        setIsAuthenticated(false);
      }
    }
    setLoading(false);
  };

  const login = async (credentials) => {
    try {
      // DUMMY DATA MODE - Remove this block when connecting real API
      const dummyToken = 'dummy_jwt_token_12345';
      const dummyUser = {
        id: 1,
        name: 'Demo Admin',
        email: credentials.email,
        avatar: null,
        role: 'admin'
      };
      
      localStorage.setItem('authToken', dummyToken);
      setUser(dummyUser);
      setIsAuthenticated(true);
      return { success: true };
      
      // UNCOMMENT BELOW WHEN CONNECTING REAL API
      // const response = await authAPI.login(credentials);
      // localStorage.setItem('authToken', response.token);
      // setUser(response.user);
      // setIsAuthenticated(true);
      // return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.message || 'Login failed' 
      };
    }
  };

  const demoLogin = async () => {
    try {
      // DUMMY DATA MODE - Works without API
      const dummyToken = 'dummy_jwt_token_demo';
      const dummyUser = {
        id: 1,
        name: 'Demo Admin',
        email: 'demo@admin.com',
        avatar: null,
        role: 'admin'
      };
      
      localStorage.setItem('authToken', dummyToken);
      setUser(dummyUser);
      setIsAuthenticated(true);
      return { success: true };
      
      // UNCOMMENT BELOW WHEN CONNECTING REAL API
      // const response = await authAPI.demoLogin();
      // localStorage.setItem('authToken', response.token);
      // setUser(response.user);
      // setIsAuthenticated(true);
      // return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.message || 'Demo login failed' 
      };
    }
  };

  const logout = async () => {
    try {
      // DUMMY DATA MODE - Skip API call
      // UNCOMMENT WHEN CONNECTING REAL API
      // await authAPI.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('authToken');
      setUser(null);
      setIsAuthenticated(false);
    }
  };

  const updateProfile = async (data) => {
    try {
      const updatedUser = await authAPI.updateProfile(data);
      setUser(updatedUser);
      return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.message || 'Profile update failed' 
      };
    }
  };

  const value = {
    user,
    loading,
    isAuthenticated,
    login,
    demoLogin,
    logout,
    updateProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
