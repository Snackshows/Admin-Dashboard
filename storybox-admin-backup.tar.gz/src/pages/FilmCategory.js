import React, { useState, useEffect } from 'react';
import { FaEdit, FaTrash, FaPlus } from 'react-icons/fa';
import Table from '../components/common/Table';
import Toggle from '../components/common/Toggle';
import Modal from '../components/common/Modal';
import { categoryAPI } from '../services/api';
import './FilmCategory.css';

const FilmCategory = () => {
  const [categories, setCategories] = useState([
    { id: 1, uniqueId: '#CAT431152', name: 'Suspense', image: '/images/suspense.png', totalMovies: 3, date: '23/12/2025', active: true },
    { id: 2, uniqueId: '#CAT349951', name: 'Mystery', image: '/images/mystery.png', totalMovies: 3, date: '23/12/2025', active: true },
    { id: 3, uniqueId: '#CAT687185', name: 'Crime', image: '/images/crime.png', totalMovies: 2, date: '23/12/2025', active: true }
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState(null);
  const [formData, setFormData] = useState({ name: '', image: null });

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      // const data = await categoryAPI.getAllCategories();
      // setCategories(data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleAdd = () => {
    setCurrentCategory(null);
    setFormData({ name: '', image: null });
    setIsModalOpen(true);
  };

  const handleEdit = (category) => {
    setCurrentCategory(category);
    setFormData({ name: category.name, image: null });
    setIsModalOpen(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this category?')) {
      try {
        await categoryAPI.deleteCategory(id);
        setCategories(categories.filter(cat => cat.id !== id));
      } catch (error) {
        console.error('Error deleting category:', error);
      }
    }
  };

  const handleToggle = async (id, currentStatus) => {
    try {
      await categoryAPI.toggleStatus(id);
      setCategories(categories.map(cat => 
        cat.id === id ? { ...cat, active: !currentStatus } : cat
      ));
    } catch (error) {
      console.error('Error toggling status:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (currentCategory) {
        await categoryAPI.updateCategory(currentCategory.id, formData);
      } else {
        await categoryAPI.createCategory(formData);
      }
      setIsModalOpen(false);
      fetchCategories();
    } catch (error) {
      console.error('Error saving category:', error);
    }
  };

  const columns = [
    { header: 'NO', accessor: 'id', width: '60px' },
    { header: 'UNIQUE ID', accessor: 'uniqueId' },
    {
      header: 'CATEGORY IMAGE',
      render: (row) => (
        <div className="category-image">
          <img src={row.image} alt={row.name} />
        </div>
      )
    },
    { header: 'CATEGORY NAME', accessor: 'name' },
    { header: 'TOTAL MOVIES', accessor: 'totalMovies' },
    { header: 'DATE', accessor: 'date' },
    {
      header: 'ACTIVE',
      render: (row) => (
        <Toggle
          checked={row.active}
          onChange={() => handleToggle(row.id, row.active)}
        />
      )
    },
    {
      header: 'ACTION',
      render: (row) => (
        <div className="action-buttons">
          <button 
            className="action-btn edit-btn"
            onClick={() => handleEdit(row)}
          >
            <FaEdit />
          </button>
          <button 
            className="action-btn delete-btn"
            onClick={() => handleDelete(row.id)}
          >
            <FaTrash />
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="film-category-page">
      <div className="page-header">
        <h2 className="page-title">Film Category</h2>
        <button className="btn btn-primary" onClick={handleAdd}>
          <FaPlus /> New
        </button>
      </div>

      <Table columns={columns} data={categories} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={currentCategory ? 'Edit Film Category' : 'Add Film Category'}
      >
        <form onSubmit={handleSubmit} className="category-form">
          <div className="form-group">
            <label className="form-label">Image</label>
            <div className="file-input-container">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setFormData({ ...formData, image: e.target.files[0] })}
                className="file-input"
              />
              {formData.image && (
                <div className="preview-image">
                  <img src={URL.createObjectURL(formData.image)} alt="Preview" />
                </div>
              )}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="input-field"
              placeholder="Enter category name"
              required
            />
          </div>

          <div className="modal-actions">
            <button 
              type="button" 
              className="btn btn-outline"
              onClick={() => setIsModalOpen(false)}
            >
              Close
            </button>
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
        </form>
      </Modal>

      <div className="pagination">
        <span>Showing 1 out of 1 pages</span>
        <div className="pagination-controls">
          <button className="pagination-btn">&lt;</button>
          <button className="pagination-btn active">1</button>
          <button className="pagination-btn">&gt;</button>
        </div>
      </div>
    </div>
  );
};

export default FilmCategory;
