import React, { useState, useEffect } from 'react';
import { FaEdit, FaEye, FaHistory, FaSearch } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import Table from '../components/common/Table';
import Toggle from '../components/common/Toggle';
import { useToast } from '../components/common/Toast';
import { useConfirm } from '../components/common/ConfirmDialog';
import { SkeletonTable } from '../components/common/Loading';
import { userAPI } from '../services/api';
import './Users.css';

const Users = () => {
  const navigate = useNavigate();
  const toast = useToast();
  const confirm = useConfirm();
  
  const [users, setUsers] = useState([
    { id: 1, name: 'Guest', uniqueId: '78562828', coins: 5000, plan: 'free', date: '23/12/2025', blocked: false },
    { id: 2, name: 'Ali Hasnain', uniqueId: '40856857', coins: 5000, plan: 'free', date: '23/12/2025', blocked: false },
    { id: 3, name: 'Guest', uniqueId: '62043559', coins: 5000, plan: 'free', date: '23/12/2025', blocked: false },
    { id: 4, name: 'Guest', uniqueId: '03366158', coins: 5000, plan: 'free', date: '23/12/2025', blocked: false },
    { id: 5, name: 'Guest', uniqueId: '82415054', coins: 5000, plan: 'free', date: '23/12/2025', blocked: false },
    { id: 6, name: 'Guest', uniqueId: '27079780', coins: 5000, plan: 'free', date: '23/12/2025', blocked: false },
    { id: 7, name: 'Yan Naing Bo', uniqueId: '11879661', coins: 5000, plan: 'free', date: '23/12/2025', blocked: false },
    { id: 8, name: 'Guest', uniqueId: '45272534', coins: 5000, plan: 'free', date: '23/12/2025', blocked: false }
  ]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      // DUMMY DATA MODE - Uncomment when API is ready
      // const data = await userAPI.getAllUsers();
      // setUsers(data);
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      setLoading(false);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Failed to load users');
      setLoading(false);
    }
  };

  const handleBlockToggle = async (userId, currentStatus) => {
    const confirmed = await confirm({
      title: currentStatus ? 'Unblock User' : 'Block User',
      message: currentStatus 
        ? 'Are you sure you want to unblock this user?' 
        : 'Are you sure you want to block this user? They will not be able to access the platform.',
      confirmText: currentStatus ? 'Unblock' : 'Block',
      type: 'warning'
    });

    if (!confirmed) return;

    try {
      // DUMMY DATA MODE - Uncomment when API is ready
      // if (currentStatus) {
      //   await userAPI.unblockUser(userId);
      // } else {
      //   await userAPI.blockUser(userId);
      // }
      
      setUsers(users.map(user => 
        user.id === userId ? { ...user, blocked: !currentStatus } : user
      ));
      
      toast.success(currentStatus ? 'User unblocked successfully' : 'User blocked successfully');
    } catch (error) {
      console.error('Error toggling user block status:', error);
      toast.error('Failed to update user status');
    }
  };

  const handleViewProfile = (userId) => {
    navigate(`/user-profile/${userId}`);
  };

  const handleEdit = (userId) => {
    toast.info('Edit feature coming soon!');
    // navigate(`/users/edit/${userId}`);
  };

  const handleHistory = (userId) => {
    toast.info('History feature coming soon!');
    // navigate(`/users/history/${userId}`);
  };

  const columns = [
    {
      header: 'NO',
      accessor: 'id',
      width: '60px'
    },
    {
      header: 'USER NAME',
      accessor: 'name',
      render: (row) => (
        <div className="user-cell">
          <div className="user-avatar">
            {row.name.charAt(0)}
          </div>
          <span>{row.name}</span>
        </div>
      )
    },
    {
      header: 'UNIQUE ID',
      accessor: 'uniqueId'
    },
    {
      header: 'COINS',
      accessor: 'coins'
    },
    {
      header: 'PLAN',
      accessor: 'plan'
    },
    {
      header: 'DATE',
      accessor: 'date'
    },
    {
      header: 'BLOCK',
      render: (row) => (
        <Toggle
          checked={row.blocked}
          onChange={(checked) => handleBlockToggle(row.id, row.blocked)}
        />
      )
    },
    {
      header: 'ACTION',
      render: (row) => (
        <div className="action-buttons">
          <button 
            className="action-btn edit-btn"
            title="Edit"
            onClick={() => handleEdit(row.id)}
          >
            <FaEdit />
          </button>
          <button 
            className="action-btn view-btn"
            onClick={() => handleViewProfile(row.id)}
            title="View Profile"
          >
            <FaEye />
          </button>
          <button 
            className="action-btn history-btn"
            title="History"
            onClick={() => handleHistory(row.id)}
          >
            <FaHistory />
          </button>
        </div>
      )
    }
  ];

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.uniqueId.includes(searchQuery)
  );

  return (
    <div className="users-page">
      <div className="page-header">
        <h2 className="page-title">Real User</h2>
        <div className="search-box">
          <FaSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search here..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>
      </div>

      {loading ? (
        <SkeletonTable rows={8} columns={7} />
      ) : (
        <Table columns={columns} data={filteredUsers} />
      )}
    </div>
  );
};

export default Users;
