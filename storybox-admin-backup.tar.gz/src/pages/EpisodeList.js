import React, { useState, useEffect } from 'react';
import { FaEdit, FaTrash, FaLock, FaUnlock, FaSearch, FaPlay } from 'react-icons/fa';
import Modal from '../components/common/Modal';
import Table from '../components/common/Table';
import Toggle from '../components/common/Toggle';
import { useToast } from '../components/common/Toast';
import { useConfirm } from '../components/common/ConfirmDialog';
import { SkeletonTable } from '../components/common/Loading';
import { episodeAPI } from '../services/api';
import './EpisodeList.css';

const EpisodeList = () => {
  const toast = useToast();
  const confirm = useConfirm();
  
  const [episodes, setEpisodes] = useState([
    {
      id: 1,
      title: 'Pilot',
      filmTitle: 'Breaking Bad',
      season: 1,
      episodeNumber: 1,
      duration: '58 min',
      releaseDate: '2008-01-20',
      views: 125000,
      locked: false,
      active: true
    },
    {
      id: 2,
      title: 'The One Where Monica Gets a Roommate',
      filmTitle: 'Friends',
      season: 1,
      episodeNumber: 1,
      duration: '22 min',
      releaseDate: '1994-09-22',
      views: 456000,
      locked: false,
      active: true
    },
    {
      id: 3,
      title: 'Winter Is Coming',
      filmTitle: 'Game of Thrones',
      season: 1,
      episodeNumber: 1,
      duration: '62 min',
      releaseDate: '2011-04-17',
      views: 890000,
      locked: false,
      active: true
    },
    {
      id: 4,
      title: 'Chapter One: The Vanishing of Will Byers',
      filmTitle: 'Stranger Things',
      season: 1,
      episodeNumber: 1,
      duration: '47 min',
      releaseDate: '2016-07-15',
      views: 678000,
      locked: false,
      active: true
    },
    {
      id: 5,
      title: 'The Train Job',
      filmTitle: 'Firefly',
      season: 1,
      episodeNumber: 2,
      duration: '44 min',
      releaseDate: '2002-09-20',
      views: 234000,
      locked: true,
      active: true
    }
  ]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSeason, setFilterSeason] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentEpisode, setCurrentEpisode] = useState(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    filmTitle: '',
    season: 1,
    episodeNumber: 1,
    duration: '',
    releaseDate: '',
    description: '',
    video: null,
    thumbnail: null
  });

  useEffect(() => {
    fetchEpisodes();
  }, []);

  const fetchEpisodes = async () => {
    try {
      setLoading(true);
      // DUMMY DATA MODE - Uncomment when API is ready
      // const data = await episodeAPI.getAllEpisodes();
      // setEpisodes(data);
      
      await new Promise(resolve => setTimeout(resolve, 800));
      setLoading(false);
    } catch (error) {
      console.error('Error fetching episodes:', error);
      toast.error('Failed to load episodes');
      setLoading(false);
    }
  };

  const handleAdd = () => {
    setCurrentEpisode(null);
    setFormData({
      title: '',
      filmTitle: '',
      season: 1,
      episodeNumber: 1,
      duration: '',
      releaseDate: '',
      description: '',
      video: null,
      thumbnail: null
    });
    setIsModalOpen(true);
  };

  const handleEdit = (episode) => {
    setCurrentEpisode(episode);
    setFormData({
      title: episode.title,
      filmTitle: episode.filmTitle,
      season: episode.season,
      episodeNumber: episode.episodeNumber,
      duration: episode.duration,
      releaseDate: episode.releaseDate,
      description: episode.description || '',
      video: null,
      thumbnail: null
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (episodeId) => {
    const confirmed = await confirm({
      title: 'Delete Episode',
      message: 'Are you sure you want to delete this episode? This action cannot be undone.',
      confirmText: 'Delete',
      type: 'danger'
    });

    if (!confirmed) return;

    try {
      // DUMMY DATA MODE
      // await episodeAPI.deleteEpisode(episodeId);
      
      setEpisodes(episodes.filter(e => e.id !== episodeId));
      toast.success('Episode deleted successfully');
    } catch (error) {
      console.error('Error deleting episode:', error);
      toast.error('Failed to delete episode');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (currentEpisode) {
        // DUMMY DATA MODE
        // await episodeAPI.updateEpisode(currentEpisode.id, formData);
        
        setEpisodes(episodes.map(e => 
          e.id === currentEpisode.id ? { ...e, ...formData } : e
        ));
        toast.success('Episode updated successfully');
      } else {
        // DUMMY DATA MODE
        // const newEpisode = await episodeAPI.createEpisode(formData);
        
        const newEpisode = {
          id: episodes.length + 1,
          ...formData,
          views: 0,
          locked: false,
          active: true
        };
        setEpisodes([...episodes, newEpisode]);
        toast.success('Episode created successfully');
      }
      
      setIsModalOpen(false);
    } catch (error) {
      console.error('Error saving episode:', error);
      toast.error('Failed to save episode');
    }
  };

  const handleToggleLock = async (episodeId, currentStatus) => {
    const confirmed = await confirm({
      title: currentStatus ? 'Unlock Episode' : 'Lock Episode',
      message: currentStatus 
        ? 'Users will be able to watch this episode for free.' 
        : 'Users will need a premium subscription to watch this episode.',
      confirmText: currentStatus ? 'Unlock' : 'Lock',
      type: 'warning'
    });

    if (!confirmed) return;

    try {
      // DUMMY DATA MODE
      // await episodeAPI.toggleLock(episodeId);
      
      setEpisodes(episodes.map(e => 
        e.id === episodeId ? { ...e, locked: !currentStatus } : e
      ));
      toast.success(currentStatus ? 'Episode unlocked' : 'Episode locked');
    } catch (error) {
      console.error('Error toggling lock:', error);
      toast.error('Failed to update lock status');
    }
  };

  const handleToggleActive = async (episodeId, currentStatus) => {
    try {
      setEpisodes(episodes.map(e => 
        e.id === episodeId ? { ...e, active: !currentStatus } : e
      ));
      toast.success(currentStatus ? 'Episode deactivated' : 'Episode activated');
    } catch (error) {
      console.error('Error toggling active:', error);
      toast.error('Failed to update active status');
    }
  };

  const columns = [
    {
      header: 'NO',
      accessor: 'id',
      width: '60px'
    },
    {
      header: 'EPISODE',
      render: (row) => (
        <div className="episode-title-cell">
          <div className="episode-thumbnail-small">
            <FaPlay className="play-icon" />
          </div>
          <div>
            <div className="episode-name">{row.title}</div>
            <div className="episode-meta">S{row.season}:E{row.episodeNumber} • {row.duration}</div>
          </div>
        </div>
      )
    },
    {
      header: 'FILM/SERIES',
      accessor: 'filmTitle'
    },
    {
      header: 'SEASON',
      accessor: 'season',
      render: (row) => `Season ${row.season}`
    },
    {
      header: 'EPISODE NO.',
      accessor: 'episodeNumber',
      render: (row) => `Episode ${row.episodeNumber}`
    },
    {
      header: 'RELEASE DATE',
      accessor: 'releaseDate',
      render: (row) => new Date(row.releaseDate).toLocaleDateString()
    },
    {
      header: 'VIEWS',
      accessor: 'views',
      render: (row) => row.views.toLocaleString()
    },
    {
      header: 'LOCK',
      render: (row) => (
        <button
          className={`lock-btn ${row.locked ? 'locked' : 'unlocked'}`}
          onClick={() => handleToggleLock(row.id, row.locked)}
          title={row.locked ? 'Locked (Premium)' : 'Unlocked (Free)'}
        >
          {row.locked ? <FaLock /> : <FaUnlock />}
        </button>
      )
    },
    {
      header: 'ACTIVE',
      render: (row) => (
        <Toggle
          checked={row.active}
          onChange={() => handleToggleActive(row.id, row.active)}
        />
      )
    },
    {
      header: 'ACTION',
      render: (row) => (
        <div className="action-buttons">
          <button 
            className="action-btn edit-btn" 
            title="Edit"
            onClick={() => handleEdit(row)}
          >
            <FaEdit />
          </button>
          <button 
            className="action-btn delete-btn" 
            title="Delete"
            onClick={() => handleDelete(row.id)}
          >
            <FaTrash />
          </button>
        </div>
      )
    }
  ];

  const seasons = [...new Set(episodes.map(e => e.season))].sort((a, b) => a - b);

  const filteredEpisodes = episodes.filter(episode => {
    const matchesSearch = episode.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         episode.filmTitle.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSeason = filterSeason === 'all' || episode.season === parseInt(filterSeason);
    return matchesSearch && matchesSeason;
  });

  return (
    <div className="episode-list-page">
      <div className="page-header">
        <h2 className="page-title">Episode Management</h2>
        <button className="btn btn-primary" onClick={handleAdd}>
          + Add New Episode
        </button>
      </div>

      <div className="filters-section">
        <div className="search-box">
          <FaSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search episodes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="filter-buttons">
          <button 
            className={`filter-btn ${filterSeason === 'all' ? 'active' : ''}`}
            onClick={() => setFilterSeason('all')}
          >
            All Seasons ({episodes.length})
          </button>
          {seasons.map(season => (
            <button 
              key={season}
              className={`filter-btn ${filterSeason === season.toString() ? 'active' : ''}`}
              onClick={() => setFilterSeason(season.toString())}
            >
              Season {season} ({episodes.filter(e => e.season === season).length})
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <SkeletonTable rows={5} columns={10} />
      ) : (
        <Table columns={columns} data={filteredEpisodes} />
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={currentEpisode ? 'Edit Episode' : 'Add New Episode'}
        size="large"
      >
        <form onSubmit={handleSubmit} className="episode-form">
          <div className="form-group">
            <label className="form-label">Episode Title *</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g., Pilot, Winter Is Coming"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Film/Series Title *</label>
            <input
              type="text"
              className="input-field"
              placeholder="e.g., Breaking Bad, Friends"
              value={formData.filmTitle}
              onChange={(e) => setFormData({ ...formData, filmTitle: e.target.value })}
              required
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Season *</label>
              <input
                type="number"
                className="input-field"
                min="1"
                value={formData.season}
                onChange={(e) => setFormData({ ...formData, season: parseInt(e.target.value) })}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Episode Number *</label>
              <input
                type="number"
                className="input-field"
                min="1"
                value={formData.episodeNumber}
                onChange={(e) => setFormData({ ...formData, episodeNumber: parseInt(e.target.value) })}
                required
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Duration *</label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g., 45 min"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Release Date *</label>
              <input
                type="date"
                className="input-field"
                value={formData.releaseDate}
                onChange={(e) => setFormData({ ...formData, releaseDate: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="input-field"
              rows="4"
              placeholder="Episode description..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Video File</label>
            <input
              type="file"
              className="file-input"
              accept="video/*"
              onChange={(e) => setFormData({ ...formData, video: e.target.files[0] })}
            />
            <small className="form-hint">Max file size: 500MB. Supported formats: MP4, MKV, AVI</small>
          </div>

          <div className="form-group">
            <label className="form-label">Thumbnail Image</label>
            <input
              type="file"
              className="file-input"
              accept="image/*"
              onChange={(e) => setFormData({ ...formData, thumbnail: e.target.files[0] })}
            />
          </div>

          <div className="modal-actions">
            <button type="button" className="btn btn-outline" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              {currentEpisode ? 'Update Episode' : 'Create Episode'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default EpisodeList;
