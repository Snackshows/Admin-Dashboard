import React, { useState, useEffect } from 'react';
import { FaEdit, FaTrash, FaEye, FaSearch, FaStar } from 'react-icons/fa';
import Modal from '../components/common/Modal';
import Table from '../components/common/Table';
import Toggle from '../components/common/Toggle';
import { useToast } from '../components/common/Toast';
import { useConfirm } from '../components/common/ConfirmDialog';
import { SkeletonTable } from '../components/common/Loading';
import { filmAPI } from '../services/api';
import './FilmList.css';

const FilmList = () => {
  const toast = useToast();
  const confirm = useConfirm();
  
  const [films, setFilms] = useState([
    {
      id: 1,
      title: 'The Dark Knight',
      category: 'Action',
      type: 'Movie',
      duration: '152 min',
      year: 2008,
      rating: 9.0,
      views: 125000,
      active: true,
      trending: true,
      featured: false
    },
    {
      id: 2,
      title: 'Breaking Bad',
      category: 'Crime',
      type: 'Series',
      duration: '5 Seasons',
      year: 2008,
      rating: 9.5,
      views: 890000,
      active: true,
      trending: true,
      featured: true
    },
    {
      id: 3,
      title: 'Inception',
      category: 'Suspense',
      type: 'Movie',
      duration: '148 min',
      year: 2010,
      rating: 8.8,
      views: 456000,
      active: true,
      trending: false,
      featured: true
    },
    {
      id: 4,
      title: 'Stranger Things',
      category: 'Mystery',
      type: 'Series',
      duration: '4 Seasons',
      year: 2016,
      rating: 8.7,
      views: 678000,
      active: true,
      trending: true,
      featured: false
    },
    {
      id: 5,
      title: 'Parasite',
      category: 'Suspense',
      type: 'Movie',
      duration: '132 min',
      year: 2019,
      rating: 8.6,
      views: 234000,
      active: true,
      trending: false,
      featured: false
    }
  ]);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentFilm, setCurrentFilm] = useState(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    category: '',
    type: 'Movie',
    duration: '',
    year: new Date().getFullYear(),
    rating: 0,
    description: '',
    thumbnail: null
  });

  useEffect(() => {
    fetchFilms();
  }, []);

  const fetchFilms = async () => {
    try {
      setLoading(true);
      // DUMMY DATA MODE - Uncomment when API is ready
      // const data = await filmAPI.getAllFilms();
      // setFilms(data);
      
      await new Promise(resolve => setTimeout(resolve, 800));
      setLoading(false);
    } catch (error) {
      console.error('Error fetching films:', error);
      toast.error('Failed to load films');
      setLoading(false);
    }
  };

  const handleAdd = () => {
    setCurrentFilm(null);
    setFormData({
      title: '',
      category: '',
      type: 'Movie',
      duration: '',
      year: new Date().getFullYear(),
      rating: 0,
      description: '',
      thumbnail: null
    });
    setIsModalOpen(true);
  };

  const handleEdit = (film) => {
    setCurrentFilm(film);
    setFormData({
      title: film.title,
      category: film.category,
      type: film.type,
      duration: film.duration,
      year: film.year,
      rating: film.rating,
      description: film.description || '',
      thumbnail: null
    });
    setIsModalOpen(true);
  };

  const handleDelete = async (filmId) => {
    const confirmed = await confirm({
      title: 'Delete Film',
      message: 'Are you sure you want to delete this film? This action cannot be undone.',
      confirmText: 'Delete',
      type: 'danger'
    });

    if (!confirmed) return;

    try {
      // DUMMY DATA MODE
      // await filmAPI.deleteFilm(filmId);
      
      setFilms(films.filter(f => f.id !== filmId));
      toast.success('Film deleted successfully');
    } catch (error) {
      console.error('Error deleting film:', error);
      toast.error('Failed to delete film');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (currentFilm) {
        // DUMMY DATA MODE
        // await filmAPI.updateFilm(currentFilm.id, formData);
        
        setFilms(films.map(f => 
          f.id === currentFilm.id ? { ...f, ...formData } : f
        ));
        toast.success('Film updated successfully');
      } else {
        // DUMMY DATA MODE
        // const newFilm = await filmAPI.createFilm(formData);
        
        const newFilm = {
          id: films.length + 1,
          ...formData,
          views: 0,
          active: true,
          trending: false,
          featured: false
        };
        setFilms([...films, newFilm]);
        toast.success('Film created successfully');
      }
      
      setIsModalOpen(false);
    } catch (error) {
      console.error('Error saving film:', error);
      toast.error('Failed to save film');
    }
  };

  const handleToggleActive = async (filmId, currentStatus) => {
    try {
      // DUMMY DATA MODE
      // await filmAPI.toggleActive(filmId);
      
      setFilms(films.map(f => 
        f.id === filmId ? { ...f, active: !currentStatus } : f
      ));
      toast.success(currentStatus ? 'Film deactivated' : 'Film activated');
    } catch (error) {
      console.error('Error toggling film status:', error);
      toast.error('Failed to update film status');
    }
  };

  const handleToggleTrending = async (filmId, currentStatus) => {
    try {
      setFilms(films.map(f => 
        f.id === filmId ? { ...f, trending: !currentStatus } : f
      ));
      toast.success(currentStatus ? 'Removed from trending' : 'Added to trending');
    } catch (error) {
      console.error('Error toggling trending:', error);
      toast.error('Failed to update trending status');
    }
  };

  const columns = [
    {
      header: 'NO',
      accessor: 'id',
      width: '60px'
    },
    {
      header: 'TITLE',
      accessor: 'title',
      render: (row) => (
        <div className="film-title-cell">
          <div className="film-thumbnail-small"></div>
          <div>
            <div className="film-name">{row.title}</div>
            <div className="film-meta">{row.year} • {row.category}</div>
          </div>
        </div>
      )
    },
    {
      header: 'TYPE',
      accessor: 'type',
      render: (row) => (
        <span className={`type-badge type-${row.type.toLowerCase()}`}>
          {row.type}
        </span>
      )
    },
    {
      header: 'DURATION',
      accessor: 'duration'
    },
    {
      header: 'RATING',
      accessor: 'rating',
      render: (row) => (
        <div className="rating-cell">
          <FaStar className="star-icon" />
          <span>{row.rating}</span>
        </div>
      )
    },
    {
      header: 'VIEWS',
      accessor: 'views',
      render: (row) => row.views.toLocaleString()
    },
    {
      header: 'TRENDING',
      render: (row) => (
        <Toggle
          checked={row.trending}
          onChange={() => handleToggleTrending(row.id, row.trending)}
        />
      )
    },
    {
      header: 'ACTIVE',
      render: (row) => (
        <Toggle
          checked={row.active}
          onChange={() => handleToggleActive(row.id, row.active)}
        />
      )
    },
    {
      header: 'ACTION',
      render: (row) => (
        <div className="action-buttons">
          <button 
            className="action-btn view-btn" 
            title="View Details"
            onClick={() => toast.info('View details coming soon!')}
          >
            <FaEye />
          </button>
          <button 
            className="action-btn edit-btn" 
            title="Edit"
            onClick={() => handleEdit(row)}
          >
            <FaEdit />
          </button>
          <button 
            className="action-btn delete-btn" 
            title="Delete"
            onClick={() => handleDelete(row.id)}
          >
            <FaTrash />
          </button>
        </div>
      )
    }
  ];

  const filteredFilms = films.filter(film => {
    const matchesSearch = film.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         film.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || film.type.toLowerCase() === filterType.toLowerCase();
    return matchesSearch && matchesType;
  });

  return (
    <div className="film-list-page">
      <div className="page-header">
        <h2 className="page-title">Film & Series Management</h2>
        <button className="btn btn-primary" onClick={handleAdd}>
          + Add New Film
        </button>
      </div>

      <div className="filters-section">
        <div className="search-box">
          <FaSearch className="search-icon" />
          <input
            type="text"
            placeholder="Search films..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="search-input"
          />
        </div>

        <div className="filter-buttons">
          <button 
            className={`filter-btn ${filterType === 'all' ? 'active' : ''}`}
            onClick={() => setFilterType('all')}
          >
            All ({films.length})
          </button>
          <button 
            className={`filter-btn ${filterType === 'movie' ? 'active' : ''}`}
            onClick={() => setFilterType('movie')}
          >
            Movies ({films.filter(f => f.type === 'Movie').length})
          </button>
          <button 
            className={`filter-btn ${filterType === 'series' ? 'active' : ''}`}
            onClick={() => setFilterType('series')}
          >
            Series ({films.filter(f => f.type === 'Series').length})
          </button>
        </div>
      </div>

      {loading ? (
        <SkeletonTable rows={5} columns={9} />
      ) : (
        <Table columns={columns} data={filteredFilms} />
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={currentFilm ? 'Edit Film' : 'Add New Film'}
      >
        <form onSubmit={handleSubmit} className="film-form">
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Title *</label>
              <input
                type="text"
                className="input-field"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Type *</label>
              <select
                className="input-field"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                required
              >
                <option value="Movie">Movie</option>
                <option value="Series">Series</option>
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Category *</label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g., Action, Crime, Suspense"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Duration *</label>
              <input
                type="text"
                className="input-field"
                placeholder="e.g., 120 min or 3 Seasons"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Year *</label>
              <input
                type="number"
                className="input-field"
                min="1900"
                max={new Date().getFullYear() + 5}
                value={formData.year}
                onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Rating *</label>
              <input
                type="number"
                className="input-field"
                min="0"
                max="10"
                step="0.1"
                value={formData.rating}
                onChange={(e) => setFormData({ ...formData, rating: parseFloat(e.target.value) })}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Description</label>
            <textarea
              className="input-field"
              rows="4"
              placeholder="Film description..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Thumbnail Image</label>
            <input
              type="file"
              className="file-input"
              accept="image/*"
              onChange={(e) => setFormData({ ...formData, thumbnail: e.target.files[0] })}
            />
          </div>

          <div className="modal-actions">
            <button type="button" className="btn btn-outline" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              {currentFilm ? 'Update Film' : 'Create Film'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default FilmList;
