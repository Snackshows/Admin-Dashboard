import React, { useState, useEffect } from 'react';
import { FaUsers, FaFilm, FaVideo, FaDollarSign } from 'react-icons/fa';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { dashboardAPI } from '../services/api';
import { SkeletonStats } from '../components/common/Loading';
import './Dashboard.css';

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalUsers: 17,
    totalFilmCategory: 3,
    totalShortVideo: 81,
    totalMovieSeries: 8,
    totalRevenue: 370
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const chartData = [
    { name: 'Jan', users: 10, revenue: 250 },
    { name: 'Feb', users: 11, revenue: 270 },
    { name: 'Mar', users: 12, revenue: 290 },
    { name: 'Apr', users: 13, revenue: 310 },
    { name: 'May', users: 14, revenue: 330 },
    { name: 'Jun', users: 15, revenue: 350 },
    { name: 'Jul', users: 17, revenue: 370 },
  ];

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // DUMMY DATA MODE - Uncomment when API is ready
      // const data = await dashboardAPI.getStats();
      // setStats(data);
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      setLoading(false);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setError(error.message || 'Failed to load dashboard data');
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    fetchDashboardData();
  };

  const statCards = [
    {
      title: 'Total User',
      value: stats.totalUsers,
      icon: FaUsers,
      color: '#FF0080'
    },
    {
      title: 'Total Film Category',
      value: stats.totalFilmCategory,
      icon: FaFilm,
      color: '#FF0080'
    },
    {
      title: 'Total Short Video',
      value: stats.totalShortVideo,
      icon: FaVideo,
      color: '#FF0080'
    },
    {
      title: 'Total Movie Series',
      value: stats.totalMovieSeries,
      icon: FaVideo,
      color: '#FF0080'
    },
    {
      title: 'Total Revenue',
      value: stats.totalRevenue,
      icon: FaDollarSign,
      color: '#FF0080'
    }
  ];

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <h1 className="page-title">Welcome Admin !</h1>
          <h2 className="section-title">Dashboard</h2>
        </div>
        <div className="dashboard-actions">
          <button className="btn btn-outline" onClick={handleRefresh}>
            {loading ? 'Refreshing...' : 'Refresh Data'}
          </button>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="error-banner">
          <strong>Error:</strong> {error}
          <button onClick={handleRefresh} className="btn-link">Retry</button>
        </div>
      )}

      {/* Stats Grid */}
      {loading ? (
        <SkeletonStats count={5} />
      ) : (
        <div className="stats-grid">
          {statCards.map((stat, index) => (
            <div key={index} className="stat-card">
              <div className="stat-content">
                <div className="stat-info">
                  <div className="stat-value">{stat.value}</div>
                  <div className="stat-title">{stat.title}</div>
                  <div className="stat-progress">
                    <div 
                      className="stat-progress-bar" 
                      style={{ width: '70%', background: stat.color }}
                    ></div>
                  </div>
                </div>
                <div className="stat-icon" style={{ color: stat.color }}>
                  <stat.icon />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Analytics Chart */}
      {!loading && (
        <div className="analytics-section">
          <h3 className="section-title">Data Analytics</h3>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="users" 
                  stroke="#FF0080" 
                  name="Total User"
                  strokeWidth={2}
                />
                <Line 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#6B7280" 
                  name="Total Revenue"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
